"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const sdk_1 = __importStar(require("@scrypted/sdk"));
function generateHex(bytes) {
    try {
        return require('crypto').randomBytes(bytes).toString('hex');
    }
    catch {
        // Fallback if crypto module unavailable in Scrypted runtime
        const chars = '0123456789abcdef';
        let result = '';
        for (let i = 0; i < bytes * 2; i++) {
            result += chars[Math.floor(Math.random() * 16)];
        }
        return result;
    }
}
const nvrPluginId = '@scrypted/nvr';
const detectionPluginIds = [
    '@scrypted/openvino',
    '@scrypted/coreml',
    '@scrypted/onnx',
    '@scrypted/tensorflow-lite',
    '@scrypted/opencv',
    '@scrypted/objectdetector',
];
class ScrixPlugin extends sdk_1.ScryptedDeviceBase {
    constructor(nativeId) {
        super(nativeId);
        if (!this.storage.getItem('apiKey')) {
            const key = generateHex(32);
            this.storage.setItem('apiKey', key);
            this.console.log('Generated new API key. Copy it from plugin settings into Scrix.');
        }
    }
    // --- Settings ---
    async getSettings() {
        return [
            {
                key: 'apiKey',
                title: 'API Key',
                description: 'Copy this key into your Scrix container settings page.',
                value: this.storage.getItem('apiKey') || '',
                type: 'string',
                readonly: true,
            },
            {
                key: 'regenerateKey',
                title: 'Regenerate API Key',
                description: 'Generate a new API key. Existing Scrix containers will lose connectivity.',
                type: 'button',
            },
        ];
    }
    async putSetting(key, value) {
        if (key === 'regenerateKey') {
            const newKey = generateHex(32);
            this.storage.setItem('apiKey', newKey);
            this.console.log('API key regenerated.');
        }
    }
    // --- Auth middleware ---
    authenticate(request) {
        const auth = request.headers?.authorization;
        if (!auth)
            return false;
        const token = auth.replace('Bearer ', '');
        return token === this.storage.getItem('apiKey');
    }
    // --- Status endpoint ---
    async handleStatus(response) {
        const plugins = await sdk_1.default.systemManager.getComponent('plugins');
        const devices = sdk_1.default.systemManager.getSystemState();
        let nvrInstalled = false;
        const detectionPlugins = [];
        const detectionTypes = new Set();
        for (const [id, device] of Object.entries(devices)) {
            const interfaces = device.interfaces?.value;
            if (!interfaces)
                continue;
            if (interfaces.includes(sdk_1.ScryptedInterface.ObjectDetection)) {
                const pluginId = device.pluginId?.value;
                if (pluginId && !detectionPlugins.includes(pluginId)) {
                    detectionPlugins.push(pluginId);
                }
            }
        }
        try {
            const installedPlugins = await plugins.getInstalledPlugins();
            nvrInstalled = installedPlugins.includes('@scrypted/nvr');
        }
        catch {
            nvrInstalled = false;
        }
        // v1: standard types when NVR or detection plugins present
        const standardTypes = ['person', 'vehicle', 'animal'];
        if (nvrInstalled || detectionPlugins.length > 0) {
            standardTypes.forEach(t => detectionTypes.add(t));
        }
        const body = JSON.stringify({
            version: '1.0.0',
            connected: true,
            detectionPlugins,
            availableDetectionTypes: Array.from(detectionTypes),
            nvrInstalled,
        });
        response.send(body, {
            code: 200,
            headers: { 'Content-Type': 'application/json' },
        });
    }
    // --- Managed cameras helpers ---
    getManagedCameras() {
        const raw = this.storage.getItem('managedCameras');
        if (!raw)
            return [];
        try {
            return JSON.parse(raw);
        }
        catch {
            return [];
        }
    }
    saveManagedCameras(cameras) {
        this.storage.setItem('managedCameras', JSON.stringify(cameras));
    }
    addManagedCamera(camera) {
        const cameras = this.getManagedCameras();
        cameras.push(camera);
        this.saveManagedCameras(cameras);
    }
    removeManagedCamera(nativeId) {
        const cameras = this.getManagedCameras().filter(c => c.nativeId !== nativeId);
        this.saveManagedCameras(cameras);
    }
    findCameraByIp(ip) {
        return this.getManagedCameras().find(c => c.ip === ip);
    }
    // --- Camera creation endpoint ---
    async handleCreateCamera(request, response) {
        let body;
        try {
            body = JSON.parse(request.body || '{}');
        }
        catch {
            response.send(JSON.stringify({ error: 'Invalid JSON body' }), {
                code: 400,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        // Validate required fields
        if (!body.name || !body.ip || !body.streams?.main) {
            response.send(JSON.stringify({
                error: 'Missing required fields: name, ip, streams.main',
            }), {
                code: 400,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        // Check for duplicate IP
        const url = request.url || '';
        const params = new URLSearchParams(url.split('?')[1] || '');
        const force = params.get('force') === 'true';
        const existing = this.findCameraByIp(body.ip);
        if (existing && !force) {
            response.send(JSON.stringify({
                error: `Camera already exists at IP ${body.ip}`,
                existingId: existing.scryptedId,
                existingNativeId: existing.nativeId,
                hint: 'Use ?force=true to replace the existing camera.',
            }), {
                code: 409,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        // If force-replacing, remove the old device first
        if (existing && force) {
            try {
                await sdk_1.default.deviceManager.onDeviceRemoved(existing.nativeId);
                this.removeManagedCamera(existing.nativeId);
                this.console.log(`Removed existing camera at IP ${body.ip} (force replace).`);
            }
            catch (e) {
                this.console.error(`Failed to remove existing camera: ${e}`);
            }
        }
        // Generate nativeId: scrix-{ip_with_underscores} with crypto fallback
        let nativeId = `scrix-${body.ip.replace(/\./g, '_')}`;
        // Check if this nativeId is already in use by another camera
        const allNativeIds = sdk_1.default.deviceManager.getNativeIds();
        if (allNativeIds.includes(nativeId)) {
            nativeId = `scrix-${body.ip.replace(/\./g, '_')}-${generateHex(4)}`;
        }
        // Create the RTSP camera device in Scrypted
        const scryptedId = await sdk_1.default.deviceManager.onDeviceDiscovered({
            name: body.name,
            nativeId,
            type: sdk_1.ScryptedDeviceType.Camera,
            interfaces: [
                sdk_1.ScryptedInterface.VideoCamera,
                sdk_1.ScryptedInterface.Settings,
            ],
            info: {
                manufacturer: 'Scrix',
                ip: body.ip,
            },
        });
        // Store RTSP stream URLs in the device's storage
        const deviceStorage = sdk_1.default.deviceManager.getDeviceStorage(nativeId);
        if (deviceStorage) {
            deviceStorage.setItem('ip', body.ip);
            deviceStorage.setItem('mainStreamUrl', body.streams.main);
            if (body.streams.sub) {
                deviceStorage.setItem('subStreamUrl', body.streams.sub);
            }
            if (body.username) {
                deviceStorage.setItem('username', body.username);
            }
            if (body.password) {
                deviceStorage.setItem('password', body.password);
            }
        }
        // Track the managed camera
        const managedCamera = {
            nativeId,
            scryptedId,
            name: body.name,
            ip: body.ip,
            createdAt: new Date().toISOString(),
        };
        this.addManagedCamera(managedCamera);
        this.console.log(`Created camera "${body.name}" at ${body.ip} (nativeId: ${nativeId}, scryptedId: ${scryptedId}).`);
        // Handle mixin opt-out after a short delay to let device initialize
        const enableNvr = body.options?.enableNvr ?? true;
        const enableDetection = body.options?.enableDetection ?? true;
        if (!enableNvr || !enableDetection) {
            setTimeout(async () => {
                try {
                    const device = sdk_1.default.systemManager.getDeviceById(scryptedId);
                    if (!device)
                        return;
                    // Get current mixins
                    const state = sdk_1.default.systemManager.getSystemState();
                    const deviceState = state[scryptedId];
                    const currentMixins = deviceState?.mixins?.value;
                    if (!currentMixins || currentMixins.length === 0)
                        return;
                    // Build list of plugin IDs to exclude
                    const excludeIds = [];
                    if (!enableNvr)
                        excludeIds.push(nvrPluginId);
                    if (!enableDetection)
                        excludeIds.push(...detectionPluginIds);
                    // Filter out mixin devices that belong to excluded plugins
                    const filteredMixins = currentMixins.filter(mixinId => {
                        const mixinDevice = sdk_1.default.systemManager.getDeviceById(mixinId);
                        if (!mixinDevice)
                            return true;
                        const mixinState = state[mixinId];
                        const pluginId = mixinState?.pluginId?.value;
                        return !pluginId || !excludeIds.includes(pluginId);
                    });
                    if (filteredMixins.length !== currentMixins.length) {
                        await device.setMixins(filteredMixins);
                        this.console.log(`Mixin opt-out applied for camera "${body.name}".`);
                    }
                }
                catch (e) {
                    this.console.error(`Failed to apply mixin opt-out: ${e}`);
                }
            }, 2000);
        }
        response.send(JSON.stringify({
            id: scryptedId,
            nativeId,
            name: body.name,
            ip: body.ip,
            created: true,
        }), {
            code: 201,
            headers: { 'Content-Type': 'application/json' },
        });
    }
    // --- Camera deletion endpoint ---
    async handleDeleteCamera(request, response) {
        const url = request.url || '';
        const params = new URLSearchParams(url.split('?')[1] || '');
        const id = params.get('id');
        if (!id) {
            response.send(JSON.stringify({ error: 'Missing required query parameter: id' }), {
                code: 400,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        // Find in managed cameras by scryptedId or nativeId
        const cameras = this.getManagedCameras();
        const camera = cameras.find(c => c.scryptedId === id || c.nativeId === id);
        if (!camera) {
            response.send(JSON.stringify({ error: `Camera not found: ${id}` }), {
                code: 404,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        try {
            await sdk_1.default.deviceManager.onDeviceRemoved(camera.nativeId);
            this.removeManagedCamera(camera.nativeId);
            this.console.log(`Deleted camera "${camera.name}" (nativeId: ${camera.nativeId}).`);
            response.send(JSON.stringify({
                deleted: true,
                id: camera.scryptedId,
                nativeId: camera.nativeId,
                name: camera.name,
            }), {
                code: 200,
                headers: { 'Content-Type': 'application/json' },
            });
        }
        catch (e) {
            response.send(JSON.stringify({
                error: `Failed to delete camera: ${e}`,
            }), {
                code: 500,
                headers: { 'Content-Type': 'application/json' },
            });
        }
    }
    // --- HTTP handler ---
    async onRequest(request, response) {
        if (!this.authenticate(request)) {
            response.send(JSON.stringify({ error: 'Unauthorized' }), {
                code: 401,
                headers: { 'Content-Type': 'application/json' },
            });
            return;
        }
        const url = request.url || '';
        const method = request.method || 'GET';
        if (method === 'GET' && url.startsWith('/api/status')) {
            return this.handleStatus(response);
        }
        if (method === 'POST' && url.startsWith('/api/cameras')) {
            return this.handleCreateCamera(request, response);
        }
        if (method === 'DELETE' && url.startsWith('/api/cameras')) {
            return this.handleDeleteCamera(request, response);
        }
        response.send(JSON.stringify({ error: 'Not found' }), {
            code: 404,
            headers: { 'Content-Type': 'application/json' },
        });
    }
    // --- DeviceProvider ---
    async getDevice(nativeId) {
        return new sdk_1.ScryptedDeviceBase(nativeId);
    }
    async releaseDevice(id, nativeId) { }
}
exports.default = ScrixPlugin;
