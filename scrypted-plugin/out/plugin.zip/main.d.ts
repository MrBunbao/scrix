import { DeviceProvider, HttpRequest, HttpRequestHandler, HttpResponse, ScryptedDeviceBase, ScryptedNativeId, Setting, Settings, SettingValue } from '@scrypted/sdk';
declare class ScrixPlugin extends ScryptedDeviceBase implements HttpRequestHandler, DeviceProvider, Settings {
    constructor(nativeId?: string);
    getSettings(): Promise<Setting[]>;
    putSetting(key: string, value: SettingValue): Promise<void>;
    private authenticate;
    private handleStatus;
    private getManagedCameras;
    private saveManagedCameras;
    private addManagedCamera;
    private removeManagedCamera;
    private findCameraByIp;
    private handleCreateCamera;
    private handleDeleteCamera;
    onRequest(request: HttpRequest, response: HttpResponse): Promise<void>;
    getDevice(nativeId: ScryptedNativeId): Promise<any>;
    releaseDevice(id: string, nativeId: string): Promise<void>;
}
export default ScrixPlugin;
